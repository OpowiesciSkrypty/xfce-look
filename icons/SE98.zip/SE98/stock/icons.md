# Stock

Total **6** icons in **stock** context.

| |**scalable**|**48x48**|**32x32**|**24x24**|**22x22**|**16x16**|
|-|-|-|-|-|-|-|
|**SC-categories-fonts**|![](scalable/SC-categories-fonts.png)|![](48/SC-categories-fonts.png)|![](32/SC-categories-fonts.png)|![](24/SC-categories-fonts.png)|![](22/SC-categories-fonts.png)|![](16/SC-categories-fonts.png)|
|**stock_network-printer**|![](scalable/stock_network-printer.png)|![](48/stock_network-printer.png)|![](32/stock_network-printer.png)|![](24/stock_network-printer.png)|![](22/stock_network-printer.png)|![](16/stock_network-printer.png)|
|**stock_new-meeting**|![](scalable/stock_new-meeting.png)|![](48/stock_new-meeting.png)|![](32/stock_new-meeting.png)|![](24/../../apps/24/system-users.png)<details><summary>*link:* </summary>*../../apps/24/system-users.png*</details>|![](22/stock_new-meeting.png)|![](16/stock_new-meeting.png)|
|**stock_people**|![](scalable/stock_people.png)|![](48/stock_people.png)|![](32/../../apps/32/config-users.png)<details><summary>*link:* </summary>*../../apps/32/config-users.png*</details>|![](24/../../apps/24/config-users.png)<details><summary>*link:* </summary>*../../apps/24/config-users.png*</details>|![](22/../../apps/22/config-users.png)<details><summary>*link:* </summary>*../../apps/22/config-users.png*</details>|![](16/stock_people.png)|
|**stock_person-panel**|![](scalable/stock_person-panel.png)|![](48/stock_person-panel.png)|![](32/stock_person-panel.png)|![](24/stock_person-panel.png)|![](22/stock_person-panel.png)|![](16/stock_person-panel.png)|
|**stock_person**|![](scalable/stock_person.png)|![](48/stock_person.png)|![](32/stock_person.png)|![](24/stock_person.png)|![](22/stock_person.png)|![](16/stock_person.png)|
