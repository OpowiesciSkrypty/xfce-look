# Tools
Only the main icons are shown here (without symlinked duplicates, in sizes from 1000000x1000000 to 0x0).<br>The full icon list with sizes from 1000000x1000000 to 0x0 is there: [icons.md](icons.md)

| |**22x22**|
|-|-|
|**color-fill**|![](22/color-fill.png)|
|**draw-brush**|![](22/draw-brush.png)|
|**draw-ellipse**|![](22/draw-ellipse.png)|
|**draw-freehand**|![](22/draw-freehand.png)|
|**draw-polygon**|![](22/draw-polygon.png)|
|**draw-polyline**|![](22/draw-polyline.png)|
|**draw-rectangle**|![](22/draw-rectangle.png)|
|**draw-smudge**|![](22/draw-smudge.png)|
|**draw-star**|![](22/draw-star.png)|
|**draw-text**|![](22/draw-text.png)|
