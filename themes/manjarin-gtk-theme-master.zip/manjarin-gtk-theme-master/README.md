# Manjarin

![s](https://cn.pling.com/img/4/f/c/1/b6ee49b6e5c173586a72cad66b90a9052d86.jpg)


This theme (which is a variation of my Telinkrin-theme) is made to blend with the Manjaro-Gnome-Edition. Nautilus and Tweak-tool have a new and modern look. And theming is persistent to the smallest detail. 


the shell-theme that blends well is the shell-theme of the adapta-gtk-theme Copyright (C) 2016-2018 Tista under the license GPLv2 or later. This comes with the standard-install of the Manjaro-gnome-edition.

The icontheme in the screenshot is Papirus-maia, which also comes with the standard-install of Manjaro-gnome-edition.

Issues:

You will notice that resizing the sidebar in nautilus behaves strange. This is not a bug. Visually the sidebar will not change (to keep it alligned with the headerbar), but you will still see the pointer for resizing. For this to work properly, pleas keep the sidebar-size small as possible.


## Requirements:

GTK+ 3.20 or later. Only standard (or Ubuntu) gnome-desktop is supported. Ready for Ubuntu 18.04
Disable gnome-extensions that reside on the headerbar because they mess up the headerbar-theming.

Window-buttons-layout (min/max/close) at the right side. (DO NOT PUT IT ON THE LEFT-SIDE)
No support for left-side window-controls! There will be no future support for left-sided buttons...

### GTK2 ENGINES REQUIREMENT

- GTK2 engine Murrine
- GTK2 engine Pixbuf

Fedora/RedHat distros:
> `yum install gtk-murrine-engine gtk2-engines`<br/>

Ubuntu/Mint/Debian distros:
> `sudo apt-get install gtk2-engines-murrine gtk2-engines-pixbuf`<br/>

Arch Linux/Manjaro Linux:

> `sudo pacman -S gtk-engine-murrine gtk-engines`<br/>


Manjarin is a GTK-theme developped by PAULXFCE (2018)

This is a gnome-theme that contains a modified GTKRC and GTK.CSS.  As such it licence is GPLv2, of which the downloaded file contains a copy.


 GRAND GTK.CSS FILE is a modified GTK.CSS with each element its own settings  
 Created by PAULXFCE (2017)                              

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

    
